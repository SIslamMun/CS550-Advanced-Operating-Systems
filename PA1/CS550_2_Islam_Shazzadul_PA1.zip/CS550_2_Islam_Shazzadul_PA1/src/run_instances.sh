#!/bin/bash
# Set the build directory where P2Pal executable is located.
BUILD_DIR="build"

# Check if the executable exists.
if [ ! -x "$BUILD_DIR/P2Pal" ]; then
    echo "Error: $BUILD_DIR/P2Pal not found or not executable."
    exit 1
fi

# Create a logs directory to store output logs.
LOG_DIR="logs"
mkdir -p "$LOG_DIR"

echo "Launching 3 instances of P2Pal..."

# Launch Instance 1 (normal launch).
"$BUILD_DIR/P2Pal" &> "$LOG_DIR/instance1.log" &
PID1=$!
echo "Instance 1 launched with PID: $PID1"

# Launch Instance 2 with dynamic peer addition (simulate adding 127.0.0.1 as a peer).
"$BUILD_DIR/P2Pal" 127.0.0.1 &> "$LOG_DIR/instance2.log" &
PID2=$!
echo "Instance 2 launched with PID: $PID2"

# Launch Instance 3 (normal launch).
"$BUILD_DIR/P2Pal" &> "$LOG_DIR/instance3.log" &
PID3=$!
echo "Instance 3 launched with PID: $PID3"

echo "Instances launched with PIDs: $PID1, $PID2, $PID3"
echo "Press ENTER to terminate all instances..."
read
echo "Terminating all instances..."
kill $PID1 $PID2 $PID3

echo "Instances terminated. Check the logs in the '$LOG_DIR' directory for details."
