#include <unistd.h>  // for getpid()

#include <QApplication>
#include <QDateTime>
#include <QDebug>
#include <QFile>
#include <QHostAddress>
#include <QTextStream>

#include "mainwindow.h"
#include "networkmanager.h"

// Global pointer for our log file.
QFile *logFile = nullptr;

// Custom message handler that logs all messages (no filtering).
void customMessageHandler(QtMsgType type, const QMessageLogContext &context,
                          const QString &msg) {
  QByteArray localMsg = msg.toLocal8Bit();
  QString logMsg;
  switch (type) {
    case QtDebugMsg:
      logMsg = QString("Debug: %1").arg(localMsg.constData());
      break;
    case QtInfoMsg:
      logMsg = QString("Info: %1").arg(localMsg.constData());
      break;
    case QtWarningMsg:
      logMsg = QString("Warning: %1").arg(localMsg.constData());
      break;
    case QtCriticalMsg:
      logMsg = QString("Critical: %1").arg(localMsg.constData());
      break;
    case QtFatalMsg:
      logMsg = QString("Fatal: %1").arg(localMsg.constData());
      abort();
  }

  if (logFile && logFile->isOpen()) {
    QTextStream out(logFile);
    out << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")
        << " " << logMsg << "\n";
    out.flush();
  }
  // Also output to the console.
  fprintf(stderr, "%s\n", logMsg.toLocal8Bit().constData());
}

int main(int argc, char *argv[]) {
  // Open a log file specific to this instance using its process ID.
  qint64 pid = getpid();
  QString logFileName = QString("instance_log_%1.log").arg(pid);
  logFile = new QFile(logFileName);
  if (!logFile->open(QIODevice::WriteOnly | QIODevice::Append |
                     QIODevice::Text)) {
    fprintf(stderr, "Could not open log file: %s\n",
            logFileName.toLocal8Bit().constData());
  }
  // Install our custom message handler.
  qInstallMessageHandler(customMessageHandler);

  // Print a test log message.
  qInfo() << "Application started. PID:" << pid;

  QApplication app(argc, argv);
  MainWindow window;
  window.show();

  // For testing dynamic peer addition: if a command-line argument is provided,
  // treat it as a peer IP.
  if (argc > 1) {
    QHostAddress newPeer(argv[1]);
    window.getNetworkManager()->addPeer(newPeer);
    qInfo() << "Added peer:" << newPeer.toString();
  }

  return app.exec();
}
