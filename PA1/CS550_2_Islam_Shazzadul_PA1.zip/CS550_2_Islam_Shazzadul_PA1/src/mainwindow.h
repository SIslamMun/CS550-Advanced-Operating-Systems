#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QTextEdit;
class QPushButton;
class NetworkManager;

class MainWindow : public QMainWindow {
  Q_OBJECT
 public:
  explicit MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

  // Getter for accessing NetworkManager (for dynamic peer addition).
  NetworkManager *getNetworkManager() { return networkManager; }

 private slots:
  void sendMessage();
  void displayReceivedMessage(const QString &sender, const QString &message);

 private:
  QTextEdit *chatLog;       // Displays chat history
  QTextEdit *messageInput;  // Multi-line input with word wrap
  QPushButton *sendButton;
  NetworkManager *networkManager;
};

#endif  // MAINWINDOW_H
