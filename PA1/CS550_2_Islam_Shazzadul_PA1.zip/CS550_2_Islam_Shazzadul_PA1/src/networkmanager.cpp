#include "networkmanager.h"

#include <QDataStream>
#include <QDebug>
#include <QHostAddress>
#include <QNetworkDatagram>
#include <QUuid>

// Ensure this function is defined with the exact same signature as in the
// header.
void NetworkManager::sendDatagram(const QVariantMap &message,
                                  const QHostAddress &address, quint16 port) {
  QByteArray datagram;
  QDataStream out(&datagram, QIODevice::WriteOnly);
  out << message;
  udpSocket->writeDatagram(datagram, address, port);
}

NetworkManager::NetworkManager(QObject *parent)
    : QObject(parent),
      sequenceNumber(1),
      peerPort(45454)  // Fixed port for communication.
{
  // Generate a unique identifier for this instance.
  origin = QUuid::createUuid().toString();

  // Create and bind the UDP socket with shared options so multiple instances
  // can use the same port.
  udpSocket = new QUdpSocket(this);
  if (!udpSocket->bind(
          QHostAddress::AnyIPv4, peerPort,
          QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint)) {
    qDebug() << "Failed to bind UDP socket to port:" << peerPort;
    return;
  }
  qDebug() << "UDP Socket bound to port:" << peerPort;

  // Connect incoming datagrams.
  connect(udpSocket, &QUdpSocket::readyRead, this,
          &NetworkManager::processPendingDatagrams);

  // Set up the anti-entropy timer (every 5 seconds).
  antiEntropyTimer = new QTimer(this);
  connect(antiEntropyTimer, &QTimer::timeout, this,
          &NetworkManager::performAntiEntropy);
  antiEntropyTimer->start(5000);

  // Set up inactivity timer: if no message is sent for 10 seconds, mark chat as
  // inactive.
  inactivityTimer = new QTimer(this);
  inactivityTimer->setSingleShot(true);
  inactivityTimer->setInterval(10000);  // 10 seconds.
  connect(inactivityTimer, &QTimer::timeout, this,
          &NetworkManager::resetChatActive);

  // Initially add the broadcast address for peer discovery.
  peers.insert(QHostAddress::Broadcast);
}

void NetworkManager::resetChatActive() {
  chatActive = false;
  qDebug() << "Chat inactive, no messages sent recently.";
}

void NetworkManager::sendMessage(const QString &chatText) {
  // Mark chat as active and restart the inactivity timer.
  chatActive = true;
  inactivityTimer->start();

  // Build the chat message.
  QVariantMap message;
  message["Type"] = "Chat";
  message["ChatText"] = chatText;
  message["Origin"] = origin;
  message["SequenceNumber"] = sequenceNumber;

  // Update our vector clock for our own messages.
  vectorClock[origin] = sequenceNumber;

  // Save the message in our history for potential anti-entropy requests.
  messageHistory[origin][sequenceNumber] = message;

  // Broadcast the chat message to all peers.
  for (const QHostAddress &peer : peers) {
    sendDatagram(message, peer, peerPort);
  }

  // Set up rumor mongering: store the message for potential re-sending.
  MessageInfo info;
  info.message = message;
  info.resendTimer = new QTimer(this);
  info.resendTimer->setInterval(1500);  // 1.5-second interval.
  info.resendTimer->setSingleShot(true);
  connect(info.resendTimer, &QTimer::timeout, this,
          &NetworkManager::handleResendTimer);
  info.resendTimer->start();

  sentMessages.insert(sequenceNumber, info);
  sequenceNumber++;  // Prepare for the next message.
}

void NetworkManager::performAntiEntropy() {
  // Only log and broadcast if chat is active.
  if (!chatActive) return;

  // Build our current vector clock.
  QVariantMap vc;
  for (auto it = vectorClock.begin(); it != vectorClock.end(); ++it) {
    vc[it.key()] = it.value();
  }
  // Only proceed if the vector clock is non-empty.
  if (vc.isEmpty()) return;

  QVariantMap vcMessage;
  vcMessage["Type"] = "VectorClock";
  vcMessage["VectorClock"] = vc;
  qDebug() << "Broadcasting vector clock:" << vc;
  for (const QHostAddress &peer : peers) {
    sendDatagram(vcMessage, peer, peerPort);
  }
}

void NetworkManager::processPendingDatagrams() {
  while (udpSocket->hasPendingDatagrams()) {
    QNetworkDatagram datagram = udpSocket->receiveDatagram();
    QByteArray data = datagram.data();
    QDataStream in(&data, QIODevice::ReadOnly);
    QVariantMap receivedMessage;
    in >> receivedMessage;
    QString type = receivedMessage.value("Type", "Chat").toString();

    if (type == "Ack") {
      // Process acknowledgment for rumor mongering.
      QString ackForOrigin = receivedMessage.value("AckForOrigin").toString();
      quint32 ackSeq = receivedMessage.value("SequenceNumber").toUInt();
      if (ackForOrigin == origin && sentMessages.contains(ackSeq)) {
        MessageInfo info = sentMessages.value(ackSeq);
        info.resendTimer->stop();
        sentMessages.remove(ackSeq);
      }
      continue;
    } else if (type == "VectorClock") {
      QVariantMap receivedVectorClock =
          receivedMessage.value("VectorClock").toMap();
      // Only process non-empty vector clocks.
      if (receivedVectorClock.isEmpty()) continue;
      if (chatActive)
        qDebug() << "Received VectorClock:" << receivedVectorClock;
      for (auto it = receivedVectorClock.begin();
           it != receivedVectorClock.end(); ++it) {
        QString originKey = it.key();
        quint32 peerSeq = it.value().toUInt();
        quint32 localSeq = vectorClock.value(originKey, 0);
        if (chatActive)
          qDebug() << "For origin" << originKey << ": peerSeq =" << peerSeq
                   << ", localSeq =" << localSeq;
        if (peerSeq > localSeq) {
          QVariantMap missingRequest;
          missingRequest["Type"] = "MissingRequest";
          missingRequest["ForOrigin"] = originKey;
          missingRequest["FromSequence"] = localSeq + 1;
          missingRequest["ToSequence"] = peerSeq;
          if (chatActive)
            qDebug() << "Sending MissingRequest for" << originKey << "from"
                     << localSeq + 1 << "to" << peerSeq;
          sendDatagram(missingRequest, datagram.senderAddress(), peerPort);
        }
      }
      continue;
    } else if (type == "MissingRequest") {
      QString reqOrigin = receivedMessage.value("ForOrigin").toString();
      quint32 fromSeq = receivedMessage.value("FromSequence").toUInt();
      quint32 toSeq = receivedMessage.value("ToSequence").toUInt();
      if (chatActive)
        qDebug() << "Received MissingRequest for" << reqOrigin << "from"
                 << fromSeq << "to" << toSeq;
      if (messageHistory.contains(reqOrigin)) {
        for (quint32 seq = fromSeq; seq <= toSeq; seq++) {
          if (messageHistory[reqOrigin].contains(seq)) {
            QVariantMap msgToResend = messageHistory[reqOrigin][seq];
            if (chatActive)
              qDebug() << "Resending message for" << reqOrigin << "sequence"
                       << seq;
            sendDatagram(msgToResend, datagram.senderAddress(), peerPort);
          }
        }
      }
      continue;
    } else if (type == "Chat") {
      QString senderOrigin = receivedMessage.value("Origin").toString();
      quint32 seq = receivedMessage.value("SequenceNumber").toUInt();
      QString messageID = senderOrigin + "_" + QString::number(seq);
      if (senderOrigin != origin && !seenMessages.contains(messageID)) {
        seenMessages.insert(messageID);
        QString text = receivedMessage.value("ChatText").toString();
        QString friendlyName;
        if (peerFriendlyNames.contains(senderOrigin)) {
          friendlyName = peerFriendlyNames.value(senderOrigin);
        } else {
          friendlyName = "Peer " + QString(QChar(nextPeerLetter));
          peerFriendlyNames.insert(senderOrigin, friendlyName);
          nextPeerLetter++;
        }
        emit messageReceived(friendlyName, text);
        if (!vectorClock.contains(senderOrigin) ||
            seq > vectorClock[senderOrigin]) {
          vectorClock[senderOrigin] = seq;
        }
        messageHistory[senderOrigin][seq] = receivedMessage;
        QVariantMap ack;
        ack["Type"] = "Ack";
        ack["AckForOrigin"] = senderOrigin;
        ack["SequenceNumber"] = seq;
        ack["Sender"] = origin;
        for (const QHostAddress &peer : peers) {
          sendDatagram(ack, peer, peerPort);
        }
      }
    }
  }
}

void NetworkManager::handleResendTimer() {
  QList<quint32> keys = sentMessages.keys();
  for (quint32 seq : keys) {
    MessageInfo info = sentMessages.value(seq);
    for (const QHostAddress &peer : peers) {
      sendDatagram(info.message, peer, peerPort);
    }
    info.resendTimer->start();
  }
}

void NetworkManager::addPeer(const QHostAddress &peerAddress) {
  peers.insert(peerAddress);
  qDebug() << "Added new peer:" << peerAddress.toString();
}
