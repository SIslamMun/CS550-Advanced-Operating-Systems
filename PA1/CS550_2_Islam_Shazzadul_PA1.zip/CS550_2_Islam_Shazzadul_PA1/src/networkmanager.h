#ifndef NETWORKMANAGER_H
#define NETWORKMANAGER_H

#include <QHostAddress>
#include <QMap>
#include <QObject>
#include <QSet>
#include <QString>
#include <QTimer>
#include <QUdpSocket>
#include <QVariantMap>

class NetworkManager : public QObject {
  Q_OBJECT
 public:
  explicit NetworkManager(QObject *parent = nullptr);
  void sendMessage(const QString &chatText);

  // Dynamic peer management: add a peer by IP/hostname.
  void addPeer(const QHostAddress &peerAddress);

 signals:
  // Signal includes the sender's friendly name and message text.
  void messageReceived(const QString &sender, const QString &message);

 private slots:
  void processPendingDatagrams();
  void handleResendTimer();
  void performAntiEntropy();
  void resetChatActive();

 private:
  void sendDatagram(const QVariantMap &message, const QHostAddress &address,
                    quint16 port);

  QUdpSocket *udpSocket;
  QString origin;          // Unique identifier for this instance.
  quint32 sequenceNumber;  // Incremented with each new message.

  // Structure for sent messages (for rumor mongering).
  struct MessageInfo {
    QVariantMap message;
    QTimer *resendTimer;
  };
  QMap<quint32, MessageInfo> sentMessages;  // Keyed by sequence number.

  QSet<QString>
      seenMessages;  // Tracks processed messages ("Origin_SequenceNumber").

  // Vector clock: tracks highest sequence number seen per origin.
  QMap<QString, quint32> vectorClock;

  // Message history: stores messages per origin for anti-entropy re-sending.
  QMap<QString, QMap<quint32, QVariantMap>> messageHistory;

  // Peer discovery: set of known peers.
  QSet<QHostAddress> peers;
  quint16 peerPort;  // Fixed port (e.g., 45454).

  QTimer *antiEntropyTimer;  // Timer for periodic anti-entropy exchange.

  // Mapping from origin UUID to a friendly name (e.g., "Peer A").
  QMap<QString, QString> peerFriendlyNames;
  char nextPeerLetter = 'A';

  // Flag and timer to determine if chat is active.
  bool chatActive = false;
  QTimer *inactivityTimer;
};

#endif  // NETWORKMANAGER_H
