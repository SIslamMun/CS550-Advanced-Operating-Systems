#include "mainwindow.h"

#include <QPushButton>
#include <QTextEdit>
#include <QTextOption>
#include <QVBoxLayout>
#include <QWidget>

#include "networkmanager.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
  QWidget *centralWidget = new QWidget(this);
  setCentralWidget(centralWidget);

  // Chat log (read-only)
  chatLog = new QTextEdit(this);
  chatLog->setReadOnly(true);

  // Multi-line message input with word wrap
  messageInput = new QTextEdit(this);
  messageInput->setPlaceholderText("Type your message here...");
  messageInput->setWordWrapMode(QTextOption::WordWrap);
  messageInput->setFocus();

  // Send button
  sendButton = new QPushButton("Send", this);

  // Layout setup
  QVBoxLayout *mainLayout = new QVBoxLayout;
  mainLayout->addWidget(chatLog);
  mainLayout->addWidget(messageInput);
  mainLayout->addWidget(sendButton);
  centralWidget->setLayout(mainLayout);

  // Instantiate the network manager.
  networkManager = new NetworkManager(this);

  // Connect signals/slots. The messageReceived signal now carries the sender's
  connect(sendButton, &QPushButton::clicked, this, &MainWindow::sendMessage);
  connect(networkManager, &NetworkManager::messageReceived, this,
          &MainWindow::displayReceivedMessage);
}

MainWindow::~MainWindow() {}

void MainWindow::sendMessage() {
  QString text = messageInput->toPlainText().trimmed();
  if (text.isEmpty()) return;

  // Display own message using "You" as the sender.
  chatLog->append("<b>You:</b> " + text);
  networkManager->sendMessage(text);
  messageInput->clear();
}

void MainWindow::displayReceivedMessage(const QString &sender,
                                        const QString &message) {
  chatLog->append("<b>" + sender + ":</b> " + message);
}
