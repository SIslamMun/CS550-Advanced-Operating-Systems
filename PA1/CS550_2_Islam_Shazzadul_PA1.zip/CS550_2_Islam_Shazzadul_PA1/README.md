## Build Instructions

### Prerequisites 
- **Qt6:** Install Qt6 with Widgets and Network modules. 
- **CMake:** Version 3.14 or later. 
- **Compiler:** A C++17-compliant compiler.
### Environment setup
Hope you have linux system and gcc compiler in your pc if not follow below instruction :
- For Windows or Mac user please install Prerequisites.

- Note : i am using Pop!_OS 22.04 LTS
- Check for updates on Ubuntu and download them using:

    `sudo apt update`

    `sudo apt upgrade`

- Install gcc (C compiler), g++ and make on the Ubuntu terminal by using :

    `sudo apt-get install git build-essential gdb-multiarch qemu-system-misc gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu`

- Install Qt6 Development Packages:

    `sudo apt install qt6-base-dev qt6-tools-dev-tools libqt6core5compat6-dev
`
- Install OpenGL Dependencies:

    `sudo apt install libgl-dev libglu1-mesa-dev freeglut3-dev mesa-common-dev`


### Start program


- Navigate into the project folder by running:
       
    `cd src`

- Create a Build Directory:

    `mkdir build`

    `cd build`

- Configure the Project:

    `cmake ..`

- Compile project:

    `make`

- Run the Executable:

    `./P2Pal`

###  Automate deployment

- Make Executable:

    `cd ..`

    `chmod +x run_instances.sh`

- Run the deployment bash script:

    `./run_instances.sh`